#!/bin/bash
set -e

echo "=========================================="
echo "  Masrofy Android APK Build Script        "
echo "=========================================="

echo "1. Checking environment..."
if ! command -v node &> /dev/null; then
    echo "Error: Node.js is not installed."
    exit 1
fi

if ! command -v java &> /dev/null; then
    echo "Warning: Java JDK was not detected in PATH. Ensure JAVA_HOME is configured."
fi

echo "2. Installing dependencies..."
npm install --legacy-peer-deps

echo "3. Building web assets..."
npm run build

echo "4. Syncing Capacitor Android assets..."
npx cap sync android

echo "5. Building Android APK via Gradle..."
cd android
chmod +x gradlew
./gradlew assembleDebug --no-daemon

echo ""
echo "=========================================="
echo "  BUILD SUCCESSFUL!                       "
echo "=========================================="
echo "Your debug APK is ready at:"
echo "android/app/build/outputs/apk/debug/app-debug.apk"
echo ""
ls -lh app/build/outputs/apk/debug/*.apk 2>/dev/null || true
