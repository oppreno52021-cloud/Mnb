@echo off
echo ==========================================
echo   Masrofy Android APK Build Script (Windows)
echo ==========================================

echo 1. Installing dependencies...
call npm install --legacy-peer-deps
if %ERRORLEVEL% NEQ 0 exit /b %ERRORLEVEL%

echo 2. Building web assets...
call npm run build
if %ERRORLEVEL% NEQ 0 exit /b %ERRORLEVEL%

echo 3. Syncing Capacitor Android...
call npx cap sync android
if %ERRORLEVEL% NEQ 0 exit /b %ERRORLEVEL%

echo 4. Compiling Android APK...
cd android
call gradlew.bat assembleDebug --no-daemon
if %ERRORLEVEL% NEQ 0 exit /b %ERRORLEVEL%

echo.
echo ==========================================
echo   BUILD SUCCESSFUL!
echo ==========================================
echo Your debug APK is ready at:
echo android\app\build\outputs\apk\debug\app-debug.apk
cd ..
pause
